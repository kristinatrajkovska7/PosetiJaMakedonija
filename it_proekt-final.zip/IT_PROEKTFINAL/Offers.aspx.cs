﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Offers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection sqlConnection1 = new SqlConnection("Data Source=KRISTINA\\SQLEXPRESS;Initial Catalog=proekt_it;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        SqlDataReader reader;

        cmd.CommandText = "select * from Smestuvanja where s_id = 1";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl11.Text = ("1. " + String.Format("{0}", reader[1]));
            lbl12.Text = (String.Format("{0}", reader[2]));
            lbl13.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl14.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl15.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img1.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 2";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl21.Text = ("2. " + String.Format("{0}", reader[1]));
            lbl22.Text = (String.Format("{0}", reader[2]));
            lbl23.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl24.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl25.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img2.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 3";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl31.Text = ("3. " + String.Format("{0}", reader[1]));
            lbl32.Text = (String.Format("{0}", reader[2]));
            lbl33.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl34.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl35.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img3.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 4";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl41.Text = ("4. " + String.Format("{0}", reader[1]));
            lbl42.Text = (String.Format("{0}", reader[2]));
            lbl43.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl44.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl45.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img4.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 5";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl51.Text = ("5. " + String.Format("{0}", reader[1]));
            lbl52.Text = (String.Format("{0}", reader[2]));
            lbl53.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl54.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl55.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img5.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 6";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl61.Text = ("6. " + String.Format("{0}", reader[1]));
            lbl62.Text = (String.Format("{0}", reader[2]));
            lbl63.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl64.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl65.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img6.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 7";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl71.Text = ("7. " + String.Format("{0}", reader[1]));
            lbl72.Text = (String.Format("{0}", reader[2]));
            lbl73.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl74.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl75.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img7.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 8";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl81.Text = ("8. " + String.Format("{0}", reader[1]));
            lbl82.Text = (String.Format("{0}", reader[2]));
            lbl83.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl84.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl85.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img8.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 9";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl91.Text = ("9. " + String.Format("{0}", reader[1]));
            lbl92.Text = (String.Format("{0}", reader[2]));
            lbl93.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl94.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl95.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img9.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 10";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl101.Text = ("10. " + String.Format("{0}", reader[1]));
            lbl102.Text = (String.Format("{0}", reader[2]));
            lbl103.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl104.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl105.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img10.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 11";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl111.Text = ("11. " + String.Format("{0}", reader[1]));
            lbl112.Text = (String.Format("{0}", reader[2]));
            lbl113.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl114.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl115.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img11.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 12";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl121.Text = ("12. " + String.Format("{0}", reader[1]));
            lbl122.Text = (String.Format("{0}", reader[2]));
            lbl123.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl124.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl125.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img12.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 13";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl131.Text = ("13. " + String.Format("{0}", reader[1]));
            lbl132.Text = (String.Format("{0}", reader[2]));
            lbl133.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl134.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl135.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img13.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 14";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl141.Text = ("14. " + String.Format("{0}", reader[1]));
            lbl142.Text = (String.Format("{0}", reader[2]));
            lbl143.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl144.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl145.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img14.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 15";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            lbl151.Text = ("15. " + String.Format("{0}", reader[1]));
            lbl152.Text = (String.Format("{0}", reader[2]));
            lbl153.Text = ("<b>Цена по лице од ноќ:</b> " + String.Format("{0}", reader[3]));
            lbl154.Text = ("<b>Звезди</b>: " + String.Format("{0}", reader[5]) + "*");
            lbl155.Text = ("<b>Адреса: </b>: " + String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]));
            img15.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();
    }
}