﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection sqlConnection1 = new SqlConnection("Data Source=KRISTINA\\SQLEXPRESS;Initial Catalog=proekt_it;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        SqlDataReader reader;

        cmd.CommandText = "select * from Smestuvanja where s_id = 1";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            hl1.Text = ("1. " + String.Format("{0}", reader[1]));
            lbl11.Text = (String.Format("{0}", reader[2]));
            hl2.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 5";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();        

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            hl3.Text = ("2. " + String.Format("{0}", reader[1]));
            lbl22.Text = (String.Format("{0}", reader[2]));
            hl4.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Smestuvanja where s_id = 13";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            hl5.Text = ("3. " + String.Format("{0}", reader[1]));
            lbl33.Text = (String.Format("{0}", reader[2]));
            hl6.ImageUrl = (String.Format("{0}", reader[8]));
        }

        sqlConnection1.Close();


    }
}