﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class Cart : System.Web.UI.Page
{
    string ime, brDzvezdi, cenaPoLice, adresa;
    int cenaPoLiceInt; 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int id=0;
            string id_string = Request.QueryString["id"];
            if (id_string == null)
            {
                MultiView1.ActiveViewIndex = 0;

            }
            else
            {
                MultiView1.ActiveViewIndex = 1;
                id = int.Parse(Request.QueryString["id"]);

                int i;

                for (i = 1; i < 5; i++)
                {
                    ddlNumbers.Items.Add(i + "");
                }
                for (i = 1; i <= 12; i++)
                {
                    ddlMesec.Items.Add(i + "");
                }
                for (i = 2018; i < 2030; i++)
                {
                    ddlGodina.Items.Add(i + "");
                }



                SqlConnection sqlConnection1 = new SqlConnection("Data Source=KRISTINA\\SQLEXPRESS;Initial Catalog=proekt_it;Integrated Security=True");
                SqlCommand cmd = new SqlCommand();
                SqlDataReader reader;

                cmd.CommandText = "select * from Smestuvanja where s_id = " + id;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = sqlConnection1;

                sqlConnection1.Open();

                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ime = String.Format("{0}", reader[1]);
                    cenaPoLice = String.Format("{0}", reader[3]);
                    brDzvezdi = String.Format("{0}", reader[5]);
                    adresa = String.Format("{0}", reader[6]) + " " + String.Format("{0}", reader[7]);
                    img1.ImageUrl = (String.Format("{0}", reader[8]));
                }

                sqlConnection1.Close();
                cenaPoLiceInt = int.Parse(cenaPoLice);
                lblTekst.Text = "Го избравте сместувањето " + ime + " со " + brDzvezdi + " ѕвезди, на  адреса " + adresa + ".";
                txtCena.Text = cenaPoLice;
            }   

}

    }
    protected void checkOut_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.Date.CompareTo(checkIn.SelectedDate) < 0)
        {
            e.Day.IsSelectable = false;
        }
    }

    protected void checkIn_DayRender(object sender, DayRenderEventArgs e)
    {
        if (e.Day.Date.CompareTo(DateTime.Today) < 0)
        {
            e.Day.IsSelectable = false;
        }
    }


    protected void Button2_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 3;
    }
    protected void btnContinue_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 4;
    }
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
        lblBrLica.Text = ddlNumbers.SelectedValue + "";
        int pricePerPerson = int.Parse(txtCena.Text);
        webservice.CalculatePrice ws = new webservice.CalculatePrice();        
        txtVkupnaCena.Text = ws.Calculate_Price(pricePerPerson, int.Parse(ddlNumbers.SelectedValue), 250);
        int brVeceri = ws.CalculateDateDifference(checkIn.SelectedDate, checkOut.SelectedDate);
        vkupnacena.Text = ws.FullPrice(int.Parse(txtVkupnaCena.Text), brVeceri);
        lblview4gore.Text = "Одбравте да го резервирате сместувањето за " + brVeceri + " вечери и за " + ddlNumbers.SelectedValue + " лица.";

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 5;
    }
}