﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Places : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection sqlConnection1 = new SqlConnection("Data Source=KRISTINA\\SQLEXPRESS;Initial Catalog=proekt_it;Integrated Security=True");
        SqlCommand cmd = new SqlCommand();
        SqlDataReader reader;

        cmd.CommandText = "select * from Gradovi where g_id = 1";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            hl11.Text = (String.Format("{0}", reader[1]));
            lbl11.Text = ("Оддалеченост од аеродром: " + String.Format("{0}", reader[2]) + "км");
            hl12.ImageUrl = (String.Format("{0}", reader[3]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Gradovi where g_id = 2";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            hl21.Text = (String.Format("{0}", reader[1]));
            lbl22.Text = ("Оддалеченост од аеродром: " + String.Format("{0}", reader[2]) + "км");
            hl22.ImageUrl = (String.Format("{0}", reader[3]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Gradovi where g_id = 3";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            hl31.Text = (String.Format("{0}", reader[1]));
            lbl33.Text = ("Оддалеченост од аеродром: " + String.Format("{0}", reader[2]) + "км");
            hl32.ImageUrl = (String.Format("{0}", reader[3]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Gradovi where g_id = 4";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            hl41.Text = (String.Format("{0}", reader[1]));
            lbl44.Text = ("Оддалеченост од аеродром: " + String.Format("{0}", reader[2]) + "км");
            hl42.ImageUrl = (String.Format("{0}", reader[3]));
        }

        sqlConnection1.Close();

        cmd.CommandText = "select * from Gradovi where g_id = 5";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = sqlConnection1;

        sqlConnection1.Open();

        reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            hl51.Text = (String.Format("{0}", reader[1]));
            lbl55.Text = ("Оддалеченост од аеродром: " + String.Format("{0}", reader[2]) + "км");
            hl52.ImageUrl = (String.Format("{0}", reader[3]));
        }

        sqlConnection1.Close();
    }
}