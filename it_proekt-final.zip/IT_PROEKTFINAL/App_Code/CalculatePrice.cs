﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for CalculatePrice
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class CalculatePrice : System.Web.Services.WebService
{

    public CalculatePrice()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string Calculate_Price(int vkupnaCena, int brLica, int fees)
    {
        string vrednost = "";
        int vk;
        vk = (vkupnaCena * brLica) + fees;
        vrednost = vk.ToString();
        return vrednost;
    }

    [WebMethod]
    public int CalculateDateDifference(DateTime ci, DateTime co)
    {
        int razlika = 0;
        string od = ci.ToShortDateString();
        string do_ = co.ToShortDateString();
        string[] s1 = od.Split('.');
        string[] s2 = do_.Split('.');
        razlika = (int.Parse(s2[2]) - int.Parse(s1[2])) * 365;
        razlika = razlika + ((int.Parse(s2[1]) - int.Parse(s1[1])) * 31);
        razlika = razlika + ((int.Parse(s2[0]) - int.Parse(s1[0])));
        return razlika;
    }
    [WebMethod]
    public string FullPrice(int vkupnaCena, int brVeceri)
    {
        int cena = vkupnaCena * brVeceri;
        return (cena).ToString();
    }

}
